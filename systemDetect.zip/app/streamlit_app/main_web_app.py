import streamlit as st
import sys
import os

# Добавляем корневую папку проекта в путь поиска модулей
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
sys.path.insert(0, project_root)
st.session_state.path_abs = project_root


st.title("Сервис оценки эффективности сотрудников на производстве")
st.markdown("""
**Как использовать:**
1. Выдерите режим работы
2. Загрузите файл
3. Получите предсказания модели
""")

pages = os.path.join(project_root, 'app', 'streamlit_app', 'pages')
page_1 = os.path.join(pages, '1_upload_data.py')
page_2 = os.path.join(pages, '3_realtime_mode.py')

col1, col2 = st.columns(2)
with col1:
    if st.button("📁 Перейти к загрузке данных"):
        st.switch_page(page_1)

with col2:
    if st.button("Перейти к режиму реального времени"):
        st.switch_page(page_2)
