import streamlit as st
import cv2
import os

path_save = st.session_state.path_abs
path_save = os.path.join(path_save, 'yolo_cv', 'data')


def save_uploaded_video(uploaded_file, path) -> str:
    """
    Сохраняет загруженный видеофайл в папку data и возвращает путь к нему.
    """
    file_path = os.path.join(path, uploaded_file.name)
    with open(file_path, "wb") as f:
        f.write(uploaded_file.read())
    return str(file_path)


def validate_video_file(video_path: str):
    """
    Проверяет, может ли OpenCV открыть видеофайл.
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        cap.release()
        return False
    cap.release()
    return True


st.title("📁 Загрузка датасета")

uploaded_file = st.file_uploader(
    "Выберите файл (.mp4, .mov)",
    type=["mp4", "mov"],
    key="file_uploader"
)

if uploaded_file:
    try:
        # Сохраняем файл на диск
        video_path = save_uploaded_video(uploaded_file, path_save)

        # Проверяем, что OpenCV может его прочитать
        if not validate_video_file(video_path):
            st.error("Не удалось открыть видеофайл. Возможно, он повреждён или в неподдерживаемом формате.")
            st.stop()

        # Сохраняем данные в session_state
        st.session_state.video_path = video_path
        st.session_state.file_name = uploaded_file.name
        st.session_state.file_uploaded = True

        st.success(f"Видео успешно сохранено: `{video_path}`")

        # Переход на следующую страницу
        st.switch_page("pages/2_static_mode.py")

    except Exception as e:
        st.error(f"Ошибка при сохранении или обработке видео: {str(e)}")