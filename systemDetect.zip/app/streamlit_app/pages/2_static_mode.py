import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import psycopg2
from matplotlib.ticker import MaxNLocator
from typing import Tuple, Dict
import os

from yolo_cv.functions import main as main_detect


def render_custom_info(
    message: str,
    background_color: str = "#fdf0b6",
    text_color: str = "#000000",
    border_color: str = "#ffd200"
) -> None:
    """
    Отображает кастомное информационное сообщение в стиле Streamlit.
    """
    st.markdown(
        f"""
        <div style="
            padding: 1rem;
            border-radius: 0.5rem;
            background-color: {background_color};
            color: {text_color};
            border-left: 4px solid {border_color};
            margin-bottom: 1rem;
        ">
            {message}
        </div>
        """,
        unsafe_allow_html=True
    )


def connect_to_database(config: Dict[str, str]) -> psycopg2.extensions.connection:
    """
    Устанавливает подключение к PostgreSQL с использованием переданной конфигурации.
    """
    return psycopg2.connect(
        host=config["host"],
        port=config["port"],
        database=config["database"],
        user=config["user"],
        password=config["password"]
    )


def fetch_latest_workers(conn) -> pd.DataFrame:
    """
    Загружает данные о работниках с последней меткой времени appearance_time.
    """
    query = """
        SELECT 
            w.id,
            u.color AS uniform_color,
            w.appearance_time
        FROM workers w
        LEFT JOIN uniforms u ON w.uniform_id = u.id
    """
    df = pd.read_sql_query(query, conn, parse_dates=["appearance_time"])
    df["appearance_time"] = pd.to_datetime(df["appearance_time"])
    latest_time = df["appearance_time"].max()
    df = df[df["appearance_time"] == latest_time].copy()
    df["appearance_time"] = df["appearance_time"].dt.strftime("%Y-%m-%d %H:%M:%S")
    return df


def fetch_latest_activities(conn) -> pd.DataFrame:
    """
    Загружает данные об активностях с последней меткой времени start_time.
    """
    query = """
        SELECT 
            wa.worker_id,
            a.name AS activity_name,
            wa.start_time
        FROM worker_activities wa
        JOIN activities a ON wa.activity_id = a.id
    """
    df = pd.read_sql_query(query, conn, parse_dates=["start_time"])
    df["start_time"] = pd.to_datetime(df["start_time"])
    latest_time = df["start_time"].max()
    df = df[df["start_time"] == latest_time].copy()
    df["start_time"] = df["start_time"].dt.strftime("%Y-%m-%d %H:%M:%S")
    return df


def fetch_mean_time_history(conn) -> pd.DataFrame:
    """
    Загружает историю среднего времени активности сотрудников.
    """
    query = """
        SELECT last_updated, mean_seconds
        FROM mean_working_time
        ORDER BY last_updated
    """
    df = pd.read_sql_query(query, conn, parse_dates=["last_updated"])
    df["last_updated"] = pd.to_datetime(df["last_updated"])
    return df


def fetch_recent_alerts(conn, alert_type: str = "человек на путях", minutes: int = 1) -> pd.DataFrame:
    """
    Загружает актуальные предупреждения заданного типа за последние N минут.
    """
    query = f"""
        SELECT 
            alert_type,
            danger_message,
            alert_time
        FROM alerts
        WHERE alert_type = %s AND alert_time >= NOW() - INTERVAL '%s minutes'
        ORDER BY alert_time DESC
    """
    df = pd.read_sql_query(query, conn, params=(alert_type, minutes), parse_dates=["alert_time"])
    return df


@st.cache_data(ttl=0)
def load_data(db_config: Dict[str, str]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Загружает все необходимые данные: работники, активности, среднее время и предупреждения.
    """
    try:
        with connect_to_database(db_config) as conn:
            workers_df = fetch_latest_workers(conn)
            activities_df = fetch_latest_activities(conn)
            mean_time_df = fetch_mean_time_history(conn)
            alerts_df = fetch_recent_alerts(conn)
        return workers_df, activities_df, mean_time_df, alerts_df
    except Exception as e:
        st.error(f"Ошибка при загрузке базы данных: {e}")
        st.stop()


def plot_occupancy(activities_df: pd.DataFrame) -> None:
    """
    Строит график занятости сотрудников (круговая диаграмма с центральным числом).
    """
    if activities_df.empty:
        render_custom_info("Нет данных об активности сотрудников")
        return

    total_workers = len(activities_df)
    activity_counts = activities_df['activity_name'].value_counts()
    labels = activity_counts.index.tolist()
    sizes = activity_counts.values.tolist()
    colors = ['#fcaf17', '#6b6b6b']

    fig, ax = plt.subplots(figsize=(4, 4))
    wedges, _ = ax.pie(
        sizes,
        labels=None,
        colors=colors[:len(sizes)],
        startangle=90,
        wedgeprops=dict(width=0.5)
    )
    ax.text(
        0, 0,
        str(total_workers),
        horizontalalignment='center',
        verticalalignment='center',
        fontsize=20,
        fontweight='bold',
        color='black'
    )
    ax.axis('equal')
    ax.legend(
        wedges, labels,
        title="Активность",
        loc="center left",
        bbox_to_anchor=(1, 0, 0.5, 1)
    )
    plt.tight_layout()
    st.pyplot(fig)


def plot_uniform_distribution(workers_df: pd.DataFrame) -> None:
    """
    Строит гистограмму распределения сотрудников по цвету униформы.
    """
    if workers_df.empty:
        render_custom_info("Нет данных о сотрудниках")
        return

    uniform_counts = workers_df['uniform_color'].value_counts().sort_values(ascending=False)

    fig, ax = plt.subplots(figsize=(4, 4))
    ax.bar(uniform_counts.index, uniform_counts.values, color='#ffd200')
    ax.set_xlabel("Цвет униформы")
    ax.set_ylabel("Количество сотрудников")
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
    ax.grid(True, alpha=0.5)
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    st.pyplot(fig)


def plot_mean_activity_time(mean_time_df: pd.DataFrame) -> None:
    """
    Строит временной график среднего времени активности (в минутах).
    """
    if mean_time_df.empty:
        st.info("Нет данных о среднем времени активности.")
        return

    df = mean_time_df.sort_values('last_updated').copy()
    df['mean_minutes'] = df['mean_seconds'] / 60.0

    fig, ax = plt.subplots(figsize=(4, 4))
    ax.plot(
        df['last_updated'],
        df['mean_minutes'],
        color='#f99d1c',
        marker='o',
        linewidth=2,
        markersize=4
    )
    ax.set_xlabel("Время")
    ax.set_ylabel("Среднее время активности (минуты)")
    ax.set_title("Среднее время активности сотрудников во времени")
    ax.grid(True, alpha=0.5)
    plt.xticks(rotation=45)
    plt.tight_layout()
    st.pyplot(fig)


def main() -> None:
    """
    Основная функция Streamlit-приложения.
    """
    if not st.session_state.file_uploaded:
        st.error("Нет загруженного видео. Вернитесь на страницу загрузки.")
        st.stop()

    video_path = st.session_state.video_path
    main_detect(video_path)

    # === Настройка страницы ===
    st.set_page_config(layout="wide")
    st.title("Депо №1")

    # === Автообновление (закомментировано по умолчанию, как в оригинале) ===
    # st_autorefresh(interval=1000, key="dashboard_refresh")

    # === Конфигурация подключения к БД ===
    DB_CONFIG = {
        "host": os.getenv("DB_HOST", "localhost"),
        "port": os.getenv("DB_PORT", "5432"),
        "database": os.getenv("DB_NAME", "depot_analysis"),
        "user": os.getenv("DB_USER", "depot_user"),
        "password": os.getenv("DB_PASS", "depotpassword")
    }

    # === Загрузка данных ===
    workers_df, activities_df, mean_time_df, alerts_df = load_data(DB_CONFIG)

    # === Отображение активного предупреждения ===
    if not alerts_df.empty:
        latest_alert = alerts_df.iloc[0]
        st.error("⚠️ На путях находится человек!")

    # === Отображение дашборда в трёх колонках ===
    col1, col2, col3 = st.columns(3)

    with col1:
        st.subheader("Занятость сотрудников")
        plot_occupancy(activities_df)

    with col2:
        st.subheader("Униформа")
        plot_uniform_distribution(workers_df)

    with col3:
        st.subheader("Среднее время активности сотрудников")
        plot_mean_activity_time(mean_time_df)


if __name__ == "__main__":
    main()