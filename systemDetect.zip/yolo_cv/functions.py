import cv2
from ultralytics import YOLO
import numpy as np
import os
import subprocess
from pathlib import Path
from typing import Dict, Tuple, List, Any

from torch.cuda import is_available
from torch import device

from Alliance.database_ai import get_session
from Alliance.crud import WorkerCRUD, WorkerActivityCRUD
from Alliance.main_database import check_and_cleanup_tables

from PIL import Image

from datetime import datetime
from datetime import timedelta

import random

# import pytesseract


# def get_time(img: Image):
#
#     crop_box = (0, 0, 400, 70)
#     cropped = img.crop(crop_box)
#
#     # Предобработка
#     cropped = cropped.convert('L')  # в градации серого
#     threshold = 128
#     binary = cropped.point(lambda p: p > threshold and 255)
#     binary = binary.convert('1')  # чёрно-белое
#
#     # Увеличиваем для лучшего распознавания
#     scale_factor = 3
#     resized = binary.resize((binary.width * scale_factor, binary.height * scale_factor), Image.NEAREST)
#
#     # 5. Распознавание с ограничением символов
#     custom_config = r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789:- '
#     text = pytesseract.image_to_string(resized, config=custom_config).strip()
#
#     try:
#         time = datetime.fromisoformat(text)
#     except ValueError:
#         time = datetime(2025, 1, 1)
#
#     return time
#
#
def resize_frame(frame, scale_percent):
    """Функция изменяет размер изображения в процентном соотношении"""
    width = int(frame.shape[1] * scale_percent / 100)
    height = int(frame.shape[0] * scale_percent / 100)
    dim = (width, height)

    resized = cv2.resize(frame, dim, interpolation=cv2.INTER_AREA)
    return resized


def filter_tracks(centers, patience):
    """Функция для обновления хранимых кадров объекта.
    patience последних кадров будут храниться.
    """
    filter_dict = {}
    for k, i in centers.items():
        d_frames = i.items()
        filter_dict[k] = dict(list(d_frames)[-patience:])

    return filter_dict


def update_tracking(centers_old, obj_center, thr_centers, lastKey, frame, frame_max):
    """Функция отслеживания траектории движения объектов. Обновляет координаты центра объекта или создаёт новый."""
    is_new = 0
    lastpos = [(k, list(center.keys())[-1], list(center.values())[-1]) for k, center in centers_old.items()]
    lastpos = [(i[0], i[2]) for i in lastpos if abs(i[1] - frame) <= frame_max]
    # Вычисляем расстояние одного и того же объекта на 2-ух соседних кадрах
    previous_pos = [(k, obj_center) for k, centers in lastpos if
                    (np.linalg.norm(np.array(centers) - np.array(obj_center)) < thr_centers)]
    # Если расстояние < threshold, то обновляем координаты центра
    if previous_pos:
        id_obj = previous_pos[0][0]
        centers_old[id_obj][frame] = obj_center
    # Иначе модель будет думать, что на изображении появился новый объект с новым ID
    else:
        if lastKey:
            last = lastKey.split('D')[1]
            id_obj = 'ID' + str(int(last) + 1)
        else:
            id_obj = 'ID0'

        is_new = 1
        centers_old[id_obj] = {frame: obj_center}
        lastKey = list(centers_old.keys())[-1]

    return centers_old, id_obj, is_new, lastKey


def load_video_capture(video_path: str, start_frame: int = 0) -> cv2.VideoCapture:
    """Инициализирует видеопоток и перематывает его на указанный кадр."""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise IOError(f"Не удалось открыть видеофайл: {video_path}")
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    return cap


def get_video_properties(cap: cv2.VideoCapture) -> Tuple[int, int, float]:
    """Возвращает ширину, высоту и FPS исходного видео."""
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = int(round(cap.get(cv2.CAP_PROP_FPS)))
    return width, height, fps


def create_video_writer(output_path: str, codec: str, fps: float, width: int, height: int) -> cv2.VideoWriter:
    """Создаёт объект VideoWriter для записи обработанных кадров."""
    fourcc = cv2.VideoWriter_fourcc(*codec)
    return cv2.VideoWriter(output_path, fourcc, fps, (width, height))


def annotate_frame(
    frame: np.ndarray,
    bbox: Tuple[int, int, int, int],
    obj_id: str,
    confidence: float,
    font: int = cv2.FONT_HERSHEY_TRIPLEX,
    font_scale: float = 0.8,
    thickness: int = 1,
) -> None:
    """
    Рисует на кадре bounding box, ID объекта и уровень уверенности.
    """
    xmin, ymin, xmax, ymax = bbox

    # Рисуем bounding box
    cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 0, 255), 2)

    # Формируем текстовую метку
    label = f"{obj_id}:{confidence:.2f}"

    # Рассчитываем размер текста для размещения фона
    (text_w, text_h), _ = cv2.getTextSize(label, font, font_scale, thickness)

    # Координаты фона под текст (немного выше bounding box'а)
    bg_x1, bg_y1 = xmin, ymin - text_h - 5
    bg_x2, bg_y2 = xmin + text_w + 5, ymin

    # Тёмно-серый фон под текст
    cv2.rectangle(frame, (bg_x1, bg_y1), (bg_x2, bg_y2), (50, 50, 50), -1)

    # Белый текст поверх фона
    cv2.putText(
        img=frame,
        text=label,
        org=(xmin + 3, ymin - 2),
        fontFace=font,
        fontScale=font_scale,
        color=(255, 255, 255),
        thickness=thickness,
    )


def process_frame(
    frame: np.ndarray,
    yolo_result: Any,
    target_classes: List[int],
    centers_old: Dict,
    thr_centers: int,
    current_frame_idx: int,
    frame_max: int,
    last_key: str,
    session=None,
    time=None,
    per_sec=False
) -> Tuple[Dict, str]:
    """
    Обрабатывает один кадр: извлекает детекции, обновляет трекинг и аннотирует кадр.
    Возвращает обновлённый словарь треков и последний использованный ключ.
    """
    boxes = yolo_result[0].boxes
    if boxes is None or len(boxes) == 0:
        return centers_old, last_key

    # Переносим данные на CPU
    xyxy = boxes.xyxy.cpu().numpy()
    confs = boxes.conf.cpu().numpy()
    class_ids = boxes.cls.cpu().numpy().astype(int)

    for i in range(len(xyxy)):
        cls_id = class_ids[i]
        if cls_id not in target_classes:
            continue

        xmin, ymin, xmax, ymax = map(int, xyxy[i])
        conf = float(confs[i])

        # Вычисляем центр bounding box'а
        center_x = (xmin + xmax) // 2
        center_y = (ymin + ymax) // 2

        # Обновляем трекинг: получаем или назначаем ID объекта
        centers_old, obj_id, is_new, last_key = update_tracking(
            centers_old,
            (center_x, center_y),
            thr_centers,
            last_key,
            current_frame_idx,
            frame_max,
        )

        if per_sec:
            worker = WorkerCRUD.create_worker(
                session,
                1,  # Номер поезда
                4,  # Цвет формы
                True,
                time
            )

            activity = WorkerActivityCRUD.create_worker_activity(
                session,
                random.randint(1, 3),
                1,  # работает
                time,
                None
            )

        # Аннотируем кадр
        annotate_frame(frame, (xmin, ymin, xmax, ymax), obj_id, conf)

    return centers_old, last_key


def finalize_video(tmp_path: str, output_path: str) -> None:
    """Конвертирует временный видеофайл в итоговый формат с помощью ffmpeg и удаляет временный файл."""
    if os.path.exists(output_path):
        os.remove(output_path)

    subprocess.run([
        "ffmpeg",
        "-i", tmp_path,
        "-crf", "18",              # качество ~без потерь
        "-preset", "veryfast",     # высокая скорость кодирования
        "-hide_banner",
        "-loglevel", "error",
        "-vcodec", "libx264",
        output_path
    ], check=True)

    os.remove(tmp_path)


def main(video_path: str = None) -> None:
    """Основная функция запуска пайплайна обработки видео."""

    device_yolo = device('cuda' if is_available() else 'cpu')

    # Подключение к БД
    session = get_session()
    # Проверка БД
    check_and_cleanup_tables(session)

    base_path = Path().resolve()
    base_path = os.path.join(base_path, 'yolo_cv')

    if not video_path:
        video_path = os.path.join(base_path, 'data', "remont.mov")

    output_name = "result.mp4"

    output_path = "rep_" + output_name
    output_path = os.path.join(base_path, 'result', output_path)

    tmp_output_path = "tmp_" + "rep_" + output_name
    tmp_output_path = os.path.join(base_path, 'result', tmp_output_path)

    # === Конфигурация ===
    config = {
        "verbose": False,
        "scale_percent": 100,
        "conf_threshold": 0.4,
        "distance_threshold": 20,
        "max_frames_missing": 45,
        "tracking_patience": 100,
        "target_classes": [0],  # class 0 = 'person' in YOLO
        "codec": "mp4v",
        "start_time_sec": 120,
        "end_time_sec": 123,
    }

    print(f"[INFO] Подробный вывод: {config['verbose']}")

    # === Загрузка модели ===
    model = YOLO('models/yolo12n.pt')

    # === Получение свойств видео ===
    cap = cv2.VideoCapture(video_path)
    width, height, fps = get_video_properties(cap)
    cap.release()
    print(f"[INFO] Исходное разрешение: ({width}, {height}), FPS: {fps:.2f}")

    # === Расчёт диапазона кадров ===
    start_frame = int(fps * config["start_time_sec"])
    end_frame = int(fps * config["end_time_sec"])

    # === Инициализация видеопотока и записи ===
    cap = load_video_capture(video_path, start_frame)
    writer = create_video_writer(tmp_output_path, config["codec"], fps, width, height)

    # === Инициализация состояния трекинга ===
    centers_old: Dict = {}
    last_key = ""

    # === Основной цикл обработки ===
    per_sec = False
    my_time = datetime(2025, 1, 1)

    for frame_idx in range(start_frame, end_frame):

        if frame_idx % fps == 0:
            per_sec = True
            my_time += timedelta(seconds=1)
        else:
            per_sec = False

        # Проверка БД
        check_and_cleanup_tables(session)

        if config["verbose"]:
            print(f"Обработка кадра {frame_idx}...")

        ret, frame = cap.read()
        if not ret:
            print(f"[WARN] Не удалось прочитать кадр {frame_idx}. Прерывание.")
            break

        # img = Image.fromarray(frame)
        # time = get_time(img)

        # Масштабирование (если требуется)
        frame = resize_frame(frame, config["scale_percent"])

        # Детекция с помощью YOLO
        yolo_results = model.predict(
            frame,
            conf=config["conf_threshold"],
            classes=config["target_classes"],
            device=device_yolo,
            verbose=False
        )

        # Обработка детекций и обновление треков
        centers_old, last_key = process_frame(
            frame=frame,
            yolo_result=yolo_results,
            target_classes=config["target_classes"],
            centers_old=centers_old,
            thr_centers=config["distance_threshold"],
            current_frame_idx=frame_idx,
            frame_max=config["max_frames_missing"],
            last_key=last_key,
            session=session,
            time=my_time,
            per_sec=per_sec
        )

        # Удаление старых треков для экономии памяти
        centers_old = filter_tracks(centers_old, config["tracking_patience"])

        # Запись обработанного кадра
        writer.write(frame)

    # === Завершение ===
    cap.release()
    writer.release()

    # Конвертация и финальная запись
    finalize_video(tmp_output_path, output_path)
    print(f"[INFO] Обработка завершена. Результат сохранён: '{output_path}'")
