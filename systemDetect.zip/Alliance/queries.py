from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from datetime import datetime, timedelta
from Alliance.models import Worker, WorkerActivity, Uniform, Train, Activity


class AnalysisQueries:
    """Класс для выполнения аналитических запросов из описания"""
    
    @staticmethod
    def find_workers_repairing_train(db: Session, train_number: str, 
                                   start_time: datetime, end_time: datetime):
        """
        Запрос 1: Найти всех работников, которые чинили поезд №XXX с 14:00 до 15:00
        """
        return db.query(Worker).join(Train).join(WorkerActivity).join(Activity).filter(
            and_(
                Train.train_number == train_number,
                Activity.name.ilike('%чинит%'),
                WorkerActivity.start_time <= end_time,
                WorkerActivity.end_time >= start_time
            )
        ).all()

    @staticmethod
    def calculate_activity_time_by_uniform(db: Session, activity_name: str):
        """
        Запрос 2: Посчитать общее время, затраченное каждым сотрудником 
        (по цвету униформы) на конкретный вид деятельности
        """
        return db.query(
            Uniform.color,
            func.sum(
                func.extract('epoch', WorkerActivity.end_time - WorkerActivity.start_time)
            ).label('total_seconds')
        ).join(Worker).join(WorkerActivity).join(Activity).filter(
            Activity.name == activity_name
        ).group_by(Uniform.color).all()

    @staticmethod
    def get_workers_presence_timeline(db: Session, train_id: int, hours: int = 24):
        """
        Запрос 3: Построить график присутствия сотрудников в кадре вокруг поезда
        """
        end_time = datetime.now()
        start_time = end_time - timedelta(hours=hours)
        
        return db.query(
            Worker.appearance_time,
            Worker.disappearance_time,
            Uniform.color,
            Worker.helmet_on
        ).join(Uniform).filter(
            and_(
                Worker.train_id == train_id,
                Worker.appearance_time <= end_time,
                Worker.disappearance_time >= start_time
            )
        ).order_by(Worker.appearance_time).all()

    @staticmethod
    def calculate_helmet_usage_percentage(db: Session):
        """
        Запрос 4: Определить процент работников, которые в течение смены надевали каску
        """
        total_workers = db.query(func.count(Worker.id)).scalar()
        workers_with_helmet = db.query(func.count(Worker.id)).filter(
            Worker.helmet_on == True
        ).scalar()
        
        if total_workers > 0:
            return (workers_with_helmet / total_workers) * 100
        return 0

    @staticmethod
    def get_worker_activity_timeline(db: Session, worker_id: int):
        """
        Получить полную временную линию активности для конкретного работника
        """
        return db.query(
            WorkerActivity.start_time,
            WorkerActivity.end_time,
            Activity.name,
            Activity.description
        ).join(Activity).filter(
            WorkerActivity.worker_id == worker_id
        ).order_by(WorkerActivity.start_time).all()

    @staticmethod
    def get_busiest_trains(db: Session, limit: int = 10):
        """
        Найти поезда с наибольшим количеством работников
        """
        return db.query(
            Train.train_number,
            func.count(Worker.id).label('workers_count')
        ).join(Worker).group_by(
            Train.id, Train.train_number
        ).order_by(func.count(Worker.id).desc()).limit(limit).all()